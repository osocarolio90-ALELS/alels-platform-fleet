package com.alels.backend.assetregister.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceRow;
import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceUpdateRequest;
import com.alels.backend.assetregister.dto.EnergyReferenceDtos.ProviderSyncResponse;
import com.alels.backend.assetregister.repository.EnergyReferenceRepository;
import com.alels.backend.serverops.shared.security.JwtUserContext;
import com.alels.backend.serverops.shared.security.RoleNormalizer;

@Service
public class EnergyReferenceService {
    private final EnergyReferenceRepository repository;

    public EnergyReferenceService(EnergyReferenceRepository repository) {
        this.repository = repository;
    }

    public List<EnergyReferenceRow> list(JwtUserContext actor) {
        requireReferenceAccess(actor);
        return repository.findAll();
    }

    public ProviderSyncResponse updateFromProvider(JwtUserContext actor) {
        requireReferenceAccess(actor);
        int updated = repository.syncFromProvider(actor.userId(), actor.companyId());
        return new ProviderSyncResponse(true, updated, "Harga referensi berhasil disinkronkan dari provider baseline.");
    }

    public void updateManual(JwtUserContext actor, Long id, EnergyReferenceUpdateRequest request) {
        requireSuperAdmin(actor);
        validate(request);
        repository.findSnapshot(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Harga referensi tidak ditemukan."));
        repository.updateManual(id, request, actor.userId(), actor.companyId());
    }

    private void validate(EnergyReferenceUpdateRequest request) {
        if (request == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request wajib diisi.");
        if (isNegative(request.referencePriceCountry())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Reference Price Country tidak boleh negatif.");
        if (isNegative(request.referencePriceGlobalUsd())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Reference Price Global tidak boleh negatif.");
        if (isNegative(request.providerReferencePriceCountry())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provider Reference Price Country tidak boleh negatif.");
        if (isNegative(request.providerReferencePriceGlobalUsd())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provider Reference Price Global tidak boleh negatif.");
        if (tooLong(request.sourceName(), 120)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Source terlalu panjang.");
        if (tooLong(request.providerStatus(), 40)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provider status terlalu panjang.");
    }

    private boolean isNegative(BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) < 0;
    }

    private boolean tooLong(String value, int max) {
        return value != null && value.trim().length() > max;
    }

    private void requireReferenceAccess(JwtUserContext actor) {
        String role = role(actor);
        if (!List.of("SUPERADMIN", "ADMIN").contains(role)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Harga Referensi hanya untuk Superadmin dan Admin.");
        }
    }

    private void requireSuperAdmin(JwtUserContext actor) {
        if (!"SUPERADMIN".equals(role(actor))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Edit manual harga referensi hanya untuk Superadmin.");
        }
    }

    private String role(JwtUserContext actor) {
        return RoleNormalizer.normalize(actor.role());
    }
}
