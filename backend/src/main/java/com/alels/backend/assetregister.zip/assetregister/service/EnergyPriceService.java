package com.alels.backend.assetregister.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.alels.backend.assetregister.dto.EnergyPriceDtos.EnergyPriceRow;
import com.alels.backend.assetregister.dto.EnergyPriceDtos.EnergyPriceUpdateRequest;
import com.alels.backend.assetregister.repository.EnergyPriceRepository;
import com.alels.backend.serverops.shared.security.JwtUserContext;
import com.alels.backend.serverops.shared.security.RoleNormalizer;

@Service
public class EnergyPriceService {
    private final EnergyPriceRepository repository;

    public EnergyPriceService(EnergyPriceRepository repository) {
        this.repository = repository;
    }

    public List<EnergyPriceRow> list(JwtUserContext actor) {
        requireAssetRegisterAccess(actor);
        repository.ensureCompanyEnergyPrices(actor.companyId());
        return repository.findByCompany(actor.companyId());
    }

    public void update(JwtUserContext actor, Long id, EnergyPriceUpdateRequest request) {
        requireAssetRegisterAccess(actor);
        Long targetCompanyId = repository.companyIdForPrice(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Harga energy tidak ditemukan."));
        if (!repository.canAccessCompany(targetCompanyId, actor.companyId(), role(actor))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Akses harga energy ditolak.");
        }
        validate(request);
        repository.updatePrice(id, request, actor.userId());
        repository.log(actor.userId(), actor.companyId(), "ENERGY_PRICE", id, "UPDATE_ENERGY_PRICE", "{\"fields\":[\"priceEnergy\"],\"source\":\"MANUAL\"}");
    }

    private void validate(EnergyPriceUpdateRequest request) {
        if (request == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request wajib diisi.");
        if (request.priceEnergy() != null && isNegative(request.priceEnergy())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Price Energy tidak boleh negatif.");
        }
    }

    private boolean isNegative(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }

    private void requireAssetRegisterAccess(JwtUserContext actor) {
        String role = role(actor);
        if (!List.of("SUPERADMIN", "ADMIN", "OWNER", "MANAGER", "TECHUSER").contains(role)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Role tidak memiliki akses Asset Register.");
        }
        if (actor.companyId() == null) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Company user tidak valid.");
        }
    }

    private String role(JwtUserContext actor) {
        return RoleNormalizer.normalize(actor.role());
    }
}
