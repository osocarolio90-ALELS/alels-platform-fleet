package com.alels.backend.assetregister.controller;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceRow;
import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceUpdateRequest;
import com.alels.backend.assetregister.dto.EnergyReferenceDtos.ProviderSyncResponse;
import com.alels.backend.assetregister.service.EnergyReferenceService;
import com.alels.backend.serverops.shared.security.JwtUserContext;

@RestController
@RequestMapping("/api/asset-register/energy-reference-prices")
public class EnergyReferenceController {
    private final EnergyReferenceService service;

    public EnergyReferenceController(EnergyReferenceService service) {
        this.service = service;
    }

    @GetMapping
    public List<EnergyReferenceRow> list(Authentication authentication) {
        return service.list(user(authentication));
    }

    @PostMapping("/update-provider")
    public ProviderSyncResponse updateProvider(Authentication authentication) {
        return service.updateFromProvider(user(authentication));
    }

    @PutMapping("/{id}")
    public Map<String, Object> updateManual(
            Authentication authentication,
            @PathVariable Long id,
            @RequestBody EnergyReferenceUpdateRequest request
    ) {
        service.updateManual(user(authentication), id, request);
        return Map.of("success", true);
    }

    private JwtUserContext user(Authentication authentication) {
        return (JwtUserContext) authentication.getPrincipal();
    }
}
