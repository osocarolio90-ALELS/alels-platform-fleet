package com.alels.backend.assetregister.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.alels.backend.assetregister.dto.EnergyPriceDtos.EnergyPriceRow;
import com.alels.backend.assetregister.dto.EnergyPriceDtos.EnergyPriceUpdateRequest;

@Repository
public class EnergyPriceRepository {
    private final JdbcTemplate jdbcTemplate;

    public EnergyPriceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void ensureCompanyEnergyPrices(Long companyId) {
        jdbcTemplate.update("""
                INSERT INTO company_energy_prices (
                    company_id,
                    energy_id,
                    country,
                    currency,
                    price_energy,
                    reference_price_country_idr,
                    reference_price_global_usd,
                    fx_rate_to_idr,
                    price_source,
                    reference_source,
                    last_reference_update_at,
                    manual_override
                )
                SELECT c.id,
                       e.id,
                       COALESCE(NULLIF(c.country, ''), 'Indonesia'),
                       COALESCE(r.country_currency, 'IDR'),
                       COALESCE(r.reference_price_country_idr, 0),
                       r.reference_price_country_idr,
                       r.reference_price_global_usd,
                       r.fx_rate_to_idr,
                       'REFERENCE_COUNTRY',
                       COALESCE(r.source, 'ALELS_SEED_REFERENCE'),
                       COALESCE(r.provider_updated_at, NOW()),
                       FALSE
                FROM companies c
                CROSS JOIN energy_types e
                LEFT JOIN energy_reference_prices r
                       ON r.energy_id = e.id
                      AND r.country = COALESCE(NULLIF(c.country, ''), 'Indonesia')
                WHERE c.id = ?
                  AND c.deleted_at IS NULL
                  AND e.status = 'ACTIVE'
                ON CONFLICT (company_id, energy_id, country) DO UPDATE
                SET reference_price_country_idr = COALESCE(EXCLUDED.reference_price_country_idr, company_energy_prices.reference_price_country_idr),
                    reference_price_global_usd = COALESCE(EXCLUDED.reference_price_global_usd, company_energy_prices.reference_price_global_usd),
                    fx_rate_to_idr = COALESCE(EXCLUDED.fx_rate_to_idr, company_energy_prices.fx_rate_to_idr),
                    reference_source = COALESCE(EXCLUDED.reference_source, company_energy_prices.reference_source),
                    last_reference_update_at = COALESCE(EXCLUDED.last_reference_update_at, company_energy_prices.last_reference_update_at),
                    price_energy = CASE
                        WHEN company_energy_prices.manual_override = FALSE THEN COALESCE(EXCLUDED.price_energy, company_energy_prices.price_energy)
                        ELSE company_energy_prices.price_energy
                    END,
                    updated_at = NOW()
                """, companyId);
    }

    public List<EnergyPriceRow> findByCompany(Long companyId) {
        return jdbcTemplate.query("""
                SELECT cep.id,
                       cep.company_id,
                       c.company_name,
                       et.id AS energy_id,
                       et.energy_code,
                       et.energy_name,
                       et.energy_group,
                       et.unit,
                       et.vehicle_usage,
                       cep.country,
                       cep.currency,
                       cep.price_energy,
                       cep.reference_price_country_idr,
                       cep.reference_price_global_usd,
                       cep.fx_rate_to_idr,
                       cep.price_source,
                       cep.reference_source,
                       cep.last_reference_update_at,
                       cep.manual_override,
                       cep.updated_at,
                       u.email AS updated_by_email
                FROM company_energy_prices cep
                JOIN energy_types et ON et.id = cep.energy_id
                JOIN companies c ON c.id = cep.company_id
                LEFT JOIN users u ON u.id = cep.updated_by
                WHERE cep.company_id = ?
                  AND c.deleted_at IS NULL
                  AND et.status = 'ACTIVE'
                ORDER BY et.sort_order, et.energy_name
                """, rowMapper(), companyId);
    }

    public Optional<Long> companyIdForPrice(Long priceId) {
        return jdbcTemplate.query("SELECT company_id FROM company_energy_prices WHERE id = ?", (rs, rowNum) -> rs.getLong("company_id"), priceId)
                .stream()
                .findFirst();
    }

    public void updatePrice(Long priceId, EnergyPriceUpdateRequest request, Long actorUserId) {
        jdbcTemplate.update("""
                UPDATE company_energy_prices
                SET price_energy = COALESCE(?, price_energy),
                    price_source = 'MANUAL',
                    manual_override = TRUE,
                    updated_by = ?,
                    updated_at = NOW()
                WHERE id = ?
                """,
                request.priceEnergy(),
                actorUserId,
                priceId);
    }

    public boolean canAccessCompany(Long targetCompanyId, Long actorCompanyId, String role) {
        if (targetCompanyId == null || actorCompanyId == null) return false;
        String normalized = role == null ? "" : role.toUpperCase().replaceAll("[\\s_-]+", "");
        if ("SUPERADMIN".equals(normalized)) return true;
        if ("ADMIN".equals(normalized)) {
            Integer count = jdbcTemplate.queryForObject("""
                    SELECT COUNT(*)
                    FROM companies
                    WHERE id = ?
                      AND deleted_at IS NULL
                      AND company_code <> 'ALELS_TECH_INDONESIA'
                    """, Integer.class, targetCompanyId);
            return count != null && count > 0;
        }
        Integer count = jdbcTemplate.queryForObject("""
                WITH RECURSIVE tree AS (
                    SELECT id FROM companies WHERE id = ? AND deleted_at IS NULL
                    UNION ALL
                    SELECT c.id FROM companies c JOIN tree t ON c.parent_company_id = t.id WHERE c.deleted_at IS NULL
                )
                SELECT COUNT(*) FROM tree WHERE id = ?
                """, Integer.class, actorCompanyId, targetCompanyId);
        return count != null && count > 0;
    }

    public void log(Long actorUserId, Long actorCompanyId, String targetType, Long targetId, String action, String detailsJson) {
        jdbcTemplate.update("""
                INSERT INTO organization_activity_logs (actor_user_id, actor_company_id, target_type, target_id, action, details)
                VALUES (?, ?, ?, ?, ?, CAST(? AS JSONB))
                """, actorUserId, actorCompanyId, targetType, targetId, action, detailsJson == null ? "{}" : detailsJson);
    }

    private RowMapper<EnergyPriceRow> rowMapper() {
        return (rs, rowNum) -> new EnergyPriceRow(
                rs.getLong("id"),
                rs.getLong("company_id"),
                rs.getString("company_name"),
                rs.getLong("energy_id"),
                rs.getString("energy_code"),
                rs.getString("energy_name"),
                rs.getString("energy_group"),
                rs.getString("unit"),
                rs.getString("vehicle_usage"),
                rs.getString("country"),
                rs.getString("currency"),
                rs.getBigDecimal("price_energy"),
                rs.getBigDecimal("reference_price_country_idr"),
                rs.getBigDecimal("reference_price_global_usd"),
                rs.getBigDecimal("fx_rate_to_idr"),
                rs.getString("price_source"),
                rs.getString("reference_source"),
                stringOrNull(rs, "last_reference_update_at"),
                rs.getBoolean("manual_override"),
                stringOrNull(rs, "updated_at"),
                rs.getString("updated_by_email")
        );
    }

    private String stringOrNull(ResultSet rs, String column) throws SQLException {
        Object value = rs.getObject(column);
        return value == null ? null : value.toString();
    }
}
