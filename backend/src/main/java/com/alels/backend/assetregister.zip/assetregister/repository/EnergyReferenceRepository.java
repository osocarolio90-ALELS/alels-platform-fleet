package com.alels.backend.assetregister.repository;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceRow;
import com.alels.backend.assetregister.dto.EnergyReferenceDtos.EnergyReferenceUpdateRequest;

@Repository
public class EnergyReferenceRepository {
    private final JdbcTemplate jdbcTemplate;

    public EnergyReferenceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<EnergyReferenceRow> findAll() {
        return jdbcTemplate.query("""
                SELECT erp.id,
                       erp.energy_id,
                       erp.energy_code,
                       et.energy_name,
                       et.energy_group,
                       erp.unit,
                       erp.country_code,
                       erp.country_name,
                       erp.currency,
                       erp.reference_price_country,
                       erp.reference_price_global_usd,
                       erp.provider_reference_price_country,
                       erp.provider_reference_price_global_usd,
                       erp.source_name,
                       erp.source_detail,
                       erp.source_url,
                       erp.provider_status,
                       erp.provider_last_update_at,
                       erp.last_sync_at,
                       erp.updated_at,
                       u.email AS updated_by_email
                FROM energy_reference_prices erp
                JOIN energy_types et ON et.id = erp.energy_id
                LEFT JOIN users u ON u.id = erp.updated_by
                WHERE et.status = 'ACTIVE'
                ORDER BY et.sort_order, et.energy_name, erp.country_code
                """, rowMapper());
    }

    public Optional<EnergyReferenceSnapshot> findSnapshot(Long id) {
        return jdbcTemplate.query("""
                SELECT id,
                       energy_id,
                       energy_code,
                       country_code,
                       reference_price_country,
                       reference_price_global_usd,
                       source_name
                FROM energy_reference_prices
                WHERE id = ?
                """, (rs, rowNum) -> new EnergyReferenceSnapshot(
                rs.getLong("id"),
                rs.getLong("energy_id"),
                rs.getString("energy_code"),
                rs.getString("country_code"),
                rs.getBigDecimal("reference_price_country"),
                rs.getBigDecimal("reference_price_global_usd"),
                rs.getString("source_name")
        ), id).stream().findFirst();
    }

    public int syncFromProvider(Long actorUserId, Long actorCompanyId) {
        List<EnergyReferenceSnapshot> before = jdbcTemplate.query("""
                SELECT id,
                       energy_id,
                       energy_code,
                       country_code,
                       reference_price_country,
                       reference_price_global_usd,
                       source_name
                FROM energy_reference_prices
                ORDER BY id
                """, (rs, rowNum) -> new EnergyReferenceSnapshot(
                rs.getLong("id"),
                rs.getLong("energy_id"),
                rs.getString("energy_code"),
                rs.getString("country_code"),
                rs.getBigDecimal("reference_price_country"),
                rs.getBigDecimal("reference_price_global_usd"),
                rs.getString("source_name")
        ));

        int updated = jdbcTemplate.update("""
                UPDATE energy_reference_prices
                SET reference_price_country = provider_reference_price_country,
                    reference_price_global_usd = provider_reference_price_global_usd,
                    source_name = COALESCE(NULLIF(source_name, ''), 'ALELS_REFERENCE_PROVIDER'),
                    provider_status = 'SYNCED',
                    provider_last_update_at = NOW(),
                    last_sync_at = NOW(),
                    updated_by = ?,
                    updated_at = NOW()
                """, actorUserId);

        for (EnergyReferenceSnapshot snapshot : before) {
            EnergyReferenceSnapshot after = findSnapshot(snapshot.id()).orElse(snapshot);
            insertReferenceLog(actorUserId, actorCompanyId, snapshot.id(), snapshot.energyCode(), snapshot.countryCode(),
                    "UPDATE_PROVIDER", snapshot.referencePriceCountry(), after.referencePriceCountry(),
                    snapshot.referencePriceGlobalUsd(), after.referencePriceGlobalUsd(), after.sourceName(),
                    "{\"mode\":\"PROVIDER_PLACEHOLDER_SYNC\"}");
        }

        syncCompanyEnergyPriceReferences();
        logOrganization(actorUserId, actorCompanyId, "ENERGY_REFERENCE_PRICE", null, "UPDATE_PROVIDER", "{\"updatedRows\":" + updated + "}");
        return updated;
    }

    public void updateManual(Long id, EnergyReferenceUpdateRequest request, Long actorUserId, Long actorCompanyId) {
        EnergyReferenceSnapshot before = findSnapshot(id).orElseThrow();
        jdbcTemplate.update("""
                UPDATE energy_reference_prices
                SET reference_price_country = COALESCE(?, reference_price_country),
                    reference_price_global_usd = COALESCE(?, reference_price_global_usd),
                    provider_reference_price_country = COALESCE(?, provider_reference_price_country),
                    provider_reference_price_global_usd = COALESCE(?, provider_reference_price_global_usd),
                    source_name = COALESCE(NULLIF(TRIM(?), ''), source_name),
                    source_detail = COALESCE(NULLIF(TRIM(?), ''), source_detail),
                    source_url = COALESCE(NULLIF(TRIM(?), ''), source_url),
                    provider_status = COALESCE(NULLIF(TRIM(?), ''), 'MANUAL_OVERRIDE'),
                    provider_last_update_at = NOW(),
                    last_sync_at = NOW(),
                    updated_by = ?,
                    updated_at = NOW()
                WHERE id = ?
                """,
                request.referencePriceCountry(),
                request.referencePriceGlobalUsd(),
                request.providerReferencePriceCountry(),
                request.providerReferencePriceGlobalUsd(),
                request.sourceName(),
                request.sourceDetail(),
                request.sourceUrl(),
                request.providerStatus(),
                actorUserId,
                id);
        EnergyReferenceSnapshot after = findSnapshot(id).orElse(before);
        insertReferenceLog(actorUserId, actorCompanyId, id, after.energyCode(), after.countryCode(),
                "EDIT_REFERENCE", before.referencePriceCountry(), after.referencePriceCountry(),
                before.referencePriceGlobalUsd(), after.referencePriceGlobalUsd(), after.sourceName(),
                "{\"mode\":\"SUPERADMIN_MANUAL_EDIT\"}");
        syncCompanyEnergyPriceReferences();
        logOrganization(actorUserId, actorCompanyId, "ENERGY_REFERENCE_PRICE", id, "EDIT_REFERENCE", "{\"mode\":\"SUPERADMIN_MANUAL_EDIT\"}");
    }

    private void syncCompanyEnergyPriceReferences() {
        jdbcTemplate.update("""
                UPDATE company_energy_prices cep
                SET reference_price_country_idr = erp.reference_price_country,
                    reference_price_global_usd = erp.reference_price_global_usd,
                    reference_source = erp.source_name,
                    last_reference_update_at = erp.last_sync_at,
                    updated_at = NOW()
                FROM energy_reference_prices erp
                WHERE cep.energy_id = erp.energy_id
                  AND erp.country_code = 'ID'
                """);
    }

    private void insertReferenceLog(Long actorUserId, Long actorCompanyId, Long referenceId, String energyCode, String countryCode,
                                    String action, BigDecimal oldCountry, BigDecimal newCountry,
                                    BigDecimal oldGlobal, BigDecimal newGlobal, String sourceName, String detailsJson) {
        jdbcTemplate.update("""
                INSERT INTO energy_reference_update_logs (
                    actor_user_id,
                    actor_company_id,
                    reference_id,
                    energy_code,
                    country_code,
                    action,
                    old_reference_price_country,
                    new_reference_price_country,
                    old_reference_price_global_usd,
                    new_reference_price_global_usd,
                    source_name,
                    details
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CAST(? AS JSONB))
                """, actorUserId, actorCompanyId, referenceId, energyCode, countryCode, action,
                oldCountry, newCountry, oldGlobal, newGlobal, sourceName, detailsJson == null ? "{}" : detailsJson);
    }

    private void logOrganization(Long actorUserId, Long actorCompanyId, String targetType, Long targetId, String action, String detailsJson) {
        jdbcTemplate.update("""
                INSERT INTO organization_activity_logs (actor_user_id, actor_company_id, target_type, target_id, action, details)
                VALUES (?, ?, ?, ?, ?, CAST(? AS JSONB))
                """, actorUserId, actorCompanyId, targetType, targetId, action, detailsJson == null ? "{}" : detailsJson);
    }

    private RowMapper<EnergyReferenceRow> rowMapper() {
        return (rs, rowNum) -> new EnergyReferenceRow(
                rs.getLong("id"),
                rs.getLong("energy_id"),
                rs.getString("energy_code"),
                rs.getString("energy_name"),
                rs.getString("energy_group"),
                rs.getString("unit"),
                rs.getString("country_code"),
                rs.getString("country_name"),
                rs.getString("currency"),
                rs.getBigDecimal("reference_price_country"),
                rs.getBigDecimal("reference_price_global_usd"),
                rs.getBigDecimal("provider_reference_price_country"),
                rs.getBigDecimal("provider_reference_price_global_usd"),
                rs.getString("source_name"),
                rs.getString("source_detail"),
                rs.getString("source_url"),
                rs.getString("provider_status"),
                stringOrNull(rs, "provider_last_update_at"),
                stringOrNull(rs, "last_sync_at"),
                stringOrNull(rs, "updated_at"),
                rs.getString("updated_by_email")
        );
    }

    private String stringOrNull(ResultSet rs, String column) throws SQLException {
        Object value = rs.getObject(column);
        return value == null ? null : value.toString();
    }

    public record EnergyReferenceSnapshot(
            Long id,
            Long energyId,
            String energyCode,
            String countryCode,
            BigDecimal referencePriceCountry,
            BigDecimal referencePriceGlobalUsd,
            String sourceName
    ) {}
}
